#ifndef FUNCOES_FORNECIDAS
#define FUNCOES_FORNECIDAS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <ctype.h>

void binarioNaTela(char *nomeArquivoBinario);
void scan_quote_string(char *str);

#endif